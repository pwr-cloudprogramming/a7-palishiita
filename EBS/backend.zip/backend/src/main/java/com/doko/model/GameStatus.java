package com.doko.model;

public enum GameStatus {
    NEW, IN_PROGRESS, FINISHED
}
